# MERIIVE: User Password Manager
## MERIIVE.com
Le site final sera sur https://vault.meriive.com/

## Installation
### Tailwind :
```
npm i
```
```
npm run build
```
Enlever //Only Extension et obfusquer sur master