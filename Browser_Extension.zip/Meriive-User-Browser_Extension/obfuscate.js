const JavaScriptObfuscator = require('javascript-obfuscator');
const fs = require('fs');
const path = require('path');
console.log('Start!');
const obfuscateDirectory = (directoryPath) => {
  fs.readdir(directoryPath, (err, files) => {
    if (err) {
      console.log('Error reading directory:', err);
      return;
    }

    files.forEach((file) => {
      const filePath = path.join(directoryPath, file);

      const stat = fs.statSync(filePath);

      if (stat.isDirectory()) {
        obfuscateDirectory(filePath);
      } else {
        const fileExtension = path.extname(file);
        const fileName = path.basename(file, fileExtension);

        if (fileExtension === '.js' && !fileName.endsWith('.min')) {
          const fileContent = fs.readFileSync(filePath, 'utf-8');
          const obfuscatedCode = JavaScriptObfuscator.obfuscate(fileContent).getObfuscatedCode();
          fs.writeFileSync(filePath, obfuscatedCode, 'utf-8');
          console.log('File obfuscated:', filePath);
        }
      }
    });
  });
};

const directoryPath = path.join(__dirname, 'userSite/js');

obfuscateDirectory(directoryPath);
